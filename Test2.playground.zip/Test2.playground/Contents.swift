import UIKit

var greeting = "Hello, playground"
let myConst = "this is my first const"
var myVariable = 1408
print(myConst)
let age = 19
print(age)
let age2 = 20
print(age2)
let ageStas = 38
var access = " "
if ageStas > 35 {
    access = "Ты старпер, но можно войти в IT \n"
} else {
    access = "Круто, ты еще не старпер"
}
print(access)
